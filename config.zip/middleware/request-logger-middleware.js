/*import logger from "../utils/logger.js";

const requestLogger = (req, res, next) => {
    logger.info(`[${req.method}] ${req.originalUrl} - Body: ${JSON.stringify(req.body)}`);
    next();
};

export default requestLogger;*/
