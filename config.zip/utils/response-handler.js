/*export const successResponse = (status, message, data = null) => {
    return {
        status,
        success: true,
        message,
        data
    };
};

export const errorResponse = (status, message) => {
    return {
        status,
        success: false,
        message
    };
};*/
